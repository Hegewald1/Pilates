//import {Event} from "../../models/event.js";
//import {Team }from "../../models/team.js";

var cal = {
  /* [PROPERTIES] */
  mName : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], // Month Names
  data : null, // Events for the selected period
  sDay : 0, // Current selected day
  sMth : 0, // Current selected month
  sYear : 0, // Current selected year
  sMon : false, // Week start on Monday?

  /* [FUNCTIONS] */
  list : function () {
  // cal.list() : draw the calendar for the given month

    // BASIC CALCULATIONS
    // Note - Jan is 0 & Dec is 11 in JS.
    // Note - Sun is 0 & Sat is 6
    cal.sMth = parseInt(document.getElementById("cal-mth").value); // selected month
    cal.sYear = parseInt(document.getElementById("cal-yr").value); // selected year
    var daysInMth = new Date(cal.sYear, cal.sMth+1, 0).getDate(), // number of days in selected month
        startDay = new Date(cal.sYear, cal.sMth, 1).getDay(), // first day of the month
        endDay = new Date(cal.sYear, cal.sMth, daysInMth).getDay(); // last day of the month

    //LOAD DATA FROM DATABASE
    //cal.data = Event.find();
    let list = Event.find();
    for (const i in list) {
      let month = i.date.getMonth();
      if(month+1 == cal.sMth){
        let day = i.getDay();
        let info = `Hold: "${i.team.teamName}" \n Tid: "${i.time}" \n Sted: "${i.place}"`
        console.log(info)
        cal.data += {day: info};
      }
    }
    
    /*
    -skal tjekke på seats og users når dage bliver oprettet
    -tilføje id "full" hvis fuldt event ellers id "available"

    */
    //hvordan data skal hentes i forhold til at indsætte i cal.data
    cal.data = localStorage.getItem("cal-" + cal.sMth + "-" + cal.sYear);
    if (cal.data==null) {
      
      localStorage.setItem("cal-" + cal.sMth + "-" + cal.sYear, "{}");
      cal.data = {};
    } else {
      cal.data = JSON.parse(cal.data);
      console.log(cal.data)
    }

    // DRAWING CALCULATIONS
    // Determine the number of blank squares before start of month
    var squares = [];
    if (cal.sMon && startDay != 1) {
      var blanks = startDay==0 ? 7 : startDay ;
      for (var i=1; i<blanks; i++) { squares.push("b"); }
    }
    if (!cal.sMon && startDay != 0) {
      for (var i=0; i<startDay; i++) { squares.push("b"); }
    }

    // Populate the days of the month
    for (var i=1; i<=daysInMth; i++) { squares.push(i); }

    // Determine the number of blank squares after end of month
    if (cal.sMon && endDay != 0) {
      var blanks = endDay==6 ? 1 : 7-endDay;
      for (var i=0; i<blanks; i++) { squares.push("b"); }
    }
    if (!cal.sMon && endDay != 6) {
      var blanks = endDay==0 ? 6 : 6-endDay;
      for (var i=0; i<blanks; i++) { squares.push("b"); }
    }

    // DRAW HTML
    // Container & Table
    var container = document.getElementById("cal-container"),
        cTable = document.createElement("table");
    cTable.id = "calendar";
    container.innerHTML = "";
    container.appendChild(cTable);

    // First row - Days
    var cRow = document.createElement("tr"),
        cCell = null,
        days = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"];
    if (cal.sMon) { days.push(days.shift()); }
    for (var d of days) {
      cCell = document.createElement("td");
      cCell.innerHTML = d;
      cRow.appendChild(cCell);
    }
    cRow.classList.add("head");
    cTable.appendChild(cRow);

    // Days in Month
    var total = squares.length;
    cRow = document.createElement("tr");
    cRow.classList.add("day");
    for (var i=0; i<total; i++) {
      cCell = document.createElement("td");
      if (squares[i]=="b") { cCell.classList.add("blank"); }
      else {
        //finde event frem
        //tjekke om seats og users.count() er det samme
        //give dem className "full" hvis de er lig hinanden
        //give dem className "available" hvis de ikke er
        //users.count() må ikke være støre end seats
        //cCell.className += "full";
        cCell.innerHTML = "<div class='dd'>"+squares[i]+"</div>";
        if (cal.data[squares[i]]) {
          cCell.innerHTML += "<div class='evt'>" + cal.data[squares[i]] + "</div>";
        }
        cCell.addEventListener("click", function(){
          //show2 hvis admin
          //show1 hvis normal bruger
          //ikke sikker :) plz check szechuan sauce
          let admin = false;
          let _id = ObjectID(session.passport.user);
          User.findOne({_id: _id}, (err, data)=> {
            if(data!=null){
              admin = true;
            }
          })
          if(admin){
            cal.show2(this);
          } else {
            cal.show1(this);
          }
          
        });
      }
      cRow.appendChild(cCell);
      if (i!=0 && (i+1)%7==0) {
        cTable.appendChild(cRow);
        cRow = document.createElement("tr");
        cRow.classList.add("day");
      }
    }
    // REMOVE ANY ADD/EDIT EVENT DOCKET
    cal.close();
  },

  show1 : function(el){
    /*

    */
   //skal finde _id eller andet for at kunne finde event i databasen
    let date = new Date(this.sYear, this.sMth, this.sDay)
    let event = Event.findOne({date: date});
    //info der skal indsættes i boksen
    let info = `_ ${event} \n 
    Tidspunkt: ${event.time} \n
    Niveau: ${event.level} \n
    Sted: ${event.place} \n
    Pladser: ${event.users.count()} ud af ${event.seats}`;

    cal.sDay = el.getElementsByClassName("dd")[0].innerHTML;
    var tForm = "<h1>Infomation</h1>";
    tForm += "<input type='button' value='Afmeld' onclick='cal.afmeld()'/>";
    tForm += "<input type='button' value='Tilmeld' onclick='cal.tilmeld()'/>";
    
    //boksen skal laves og info skal indsættes
    var eForm = document.createElement("form");
    eForm.addEventListener("submit", cal.save);
    eForm.innerHTML = tForm;
    var container = document.getElementById("cal-event");
    container.innerHTML = "";
    container.appendChild(eForm);
    
  },

  show2 : function (el) {
  // cal.show() : show edit event docket for selected day
  // PARAM el : Reference back to cell clicked

    // FETCH EXISTING DATA
    cal.sDay = el.getElementsByClassName("dd")[0].innerHTML;

    // DRAW FORM
    var tForm = "<h1>" + (cal.data[cal.sDay] ? "EDIT" : "ADD") + " EVENT</h1>";
    tForm += "<div id='evt-date'>" + cal.sDay + " " + cal.mName[cal.sMth] + " " + cal.sYear + "</div>";
    tForm += "<textarea id='evt-details' required>" + (cal.data[cal.sDay] ? cal.data[cal.sDay] : "") + "</textarea>";
    tForm += "<input type='button' value='Close' onclick='cal.close()'/>";
    tForm += "<input type='button' value='Delete' onclick='cal.del()'/>";
    tForm += "<input type='submit' value='Save'/>";
    //laver en dropdown med hold
    tForm += "<select name='Hold'/>"
    let list = Team.find();
    //hvis der er oprettet teams skal de tilføjes til dropdown listen
    for (const i in list) {
      tForm += "<option value="+ i.teamName +">"+ i.teamName +"</option>"
    }


    // ATTACH
    var eForm = document.createElement("form");
    eForm.addEventListener("submit", cal.save);
    eForm.innerHTML = tForm;
    var container = document.getElementById("cal-event");
    container.innerHTML = "";
    container.appendChild(eForm);
  },

  close : function () {
  // cal.close() : close event docket

    document.getElementById("cal-event").innerHTML = "";
  },

  save : function (evt) {
  // cal.save() : save event
  //skal også gemem det i databasen
  //hvis event allerede er eksisterende skal den tjekke på dato og finde event
  //eventuelt gemme event._id inde på calendar
    evt.stopPropagation();
    evt.preventDefault();
    //tjekke om der allerede er et event
    if(document.getElementById("evt-details").value !== null){
      let date =  new Date(this.sYear, this.sMth, this.sDay);
      //hente den nye information
      cal.data[cal.sDay] = ""
      Event.findOneAndUpdate({date: date}, )
    }//opret event (baseret på valgte hold)
    else{
      //det valgte team ud fra dropdown listen
      let team;
      const event = new Event({
        _id: new mongoose.Types.ObjectId(),
        level: team.level,
        seats: team.users.count(),
        time: team.time,
        place: team.place,
        date: new Date(this.sYear, this.sMth, this.sDay), //den valgte dato (ikke sikker)
        users: team.users,
        team: team
    });
    user
    .save()
    .then(result => {
      console.log(result);
    })
    .catch(err => {
      console.log(err);
    });
    }

    //finde holdet i databasen og lave eventet ud fra det og gemme det

    cal.data[cal.sDay] = document.getElementById("evt-details").value;
    
    localStorage.setItem("cal-" + cal.sMth + "-" + cal.sYear, JSON.stringify(cal.data));
    cal.list();
  },

  del : function () {
  // cal.del() : Delete event for selected date
  //skal også slette det fra databasen
  //tjekke på dato og slette event


    if (confirm("Remove event?")) {
      delete cal.data[cal.sDay];
      //database call findAndRemove()
      localStorage.setItem("cal-" + cal.sMth + "-" + cal.sYear, JSON.stringify(cal.data));
      cal.list();
    }
  },
  afmeld : function(){
    /*
    -skal kun vises fra bruger siden
    -finde event nede i databasen
    -event.users fjern user som er logget ind
    -give user +1 ledige point
    */


  },
  tilmeld : function(){
    /*
    -tilmeld knappen skal kun kunne trykkes hvis ledige point > 0
    -ledige point -1 når user tilmeldes
    -event.user tilføj til event i databasen
    */
  }
};

// INIT - DRAW MONTH & YEAR SELECTOR
window.addEventListener("load", function () {
  // DATE NOW
  var now = new Date(),
      nowMth = now.getMonth(),
      nowYear = parseInt(now.getFullYear());

  // APPEND MONTHS SELECTOR
  var month = document.getElementById("cal-mth");
  for (var i = 0; i < 12; i++) {
    var opt = document.createElement("option");
    opt.value = i;
    opt.innerHTML = cal.mName[i];
    if (i==nowMth) { opt.selected = true; }
    month.appendChild(opt);
  }

  // APPEND YEARS SELECTOR
  // Set to 10 years range. Change this as you like.
  var year = document.getElementById("cal-yr");
  for (var i = nowYear-10; i<=nowYear+10; i++) {
    var opt = document.createElement("option");
    opt.value = i;
    opt.innerHTML = i;
    if (i==nowYear) { opt.selected = true; }
    year.appendChild(opt);
  }

  // START - DRAW CALENDAR
  document.getElementById("cal-set").addEventListener("click", cal.list);
  cal.list();
});

  // TILFØJ EVENTS EFTER DATO
function addEvents(dato) {
  let list = Team.Find();
  for (const key in list) {
    //oprettelse af event
  }
}